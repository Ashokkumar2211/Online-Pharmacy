<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "pharmacy";
$port = "3307";

$conn = mysqli_connect($host, $username, $password, $database, $port);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $productName = $_POST["productName"];
    $productPrice = $_POST["productPrice"];
    $productDescription = $_POST["productDescription"];
    $productCategory = $_POST["productCategory"];
    
    // Check if the "forAdults" checkbox is checked
    $forAdults = isset($_POST["forAdults"]) ? 1 : 0;

    $targetDirectory = "uploads/";

    $imageFileType = strtolower(pathinfo($_FILES["productImage"]["name"], PATHINFO_EXTENSION));
    $targetFile = $targetDirectory . uniqid() . '.' . $imageFileType;

    if (file_exists($targetFile)) {
        die("Error: A file with the same name already exists.");
    }

    if ($_FILES["productImage"]["size"] > 500000) {
        die("Error: The uploaded file is too large.");
    }

    $allowedExtensions = ["jpg", "jpeg", "png", "gif"];
    if (!in_array($imageFileType, $allowedExtensions)) {
        die("Error: Only JPG, JPEG, PNG, and GIF files are allowed.");
    }

    if (move_uploaded_file($_FILES["productImage"]["tmp_name"], $targetFile)) {
        $imageURL = $targetFile;

        $sql = "INSERT INTO products (name, MRP, description, category, image, adult) VALUES ('$productName', '$productPrice', '$productDescription', '$productCategory', '$imageURL', '$forAdults')";
        if (mysqli_query($conn, $sql)) {
            http_response_code(201);
            echo "Product added successfully!";
        } else {
            http_response_code(500);
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        http_response_code(500);
        echo "Error: Failed to move the image.";
    }
}

mysqli_close($conn);
?>
