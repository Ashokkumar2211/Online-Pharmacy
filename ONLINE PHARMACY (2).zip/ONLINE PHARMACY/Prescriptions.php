<?php
$servername = "localhost";
$username = "root";
$password = ""; 
$database = "pharmacy";
$port = "3307";

$conn = new mysqli($servername, $username, $password, $database, $port);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT name, email, prescription_path FROM prescriptions";

$result = $conn->query($sql);

if ($result) {
    $prescriptions = array();

    while ($row = $result->fetch_assoc()) {
        $prescription = array(
            'name' => $row['name'],
            'email' => $row['email'],
            'prescription_path' => $row['prescription_path']
        );

        $prescriptions[] = $prescription;
    }

    $conn->close();

    header('Content-Type: application/json');
    echo json_encode($prescriptions);
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

?>
