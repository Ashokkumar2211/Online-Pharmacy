<?php
session_start();

if (isset($_SESSION['user_email'])) {
    $userEmail = $_SESSION['user_email'];

    $host = "localhost";
    $username = "root";
    $password = "";
    $dbname = "pharmacy";
    $port = "3307";

    $conn = new mysqli($host, $username, $password, $dbname, $port);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // First, retrieve the user's ID based on their email.
    $userIdQuery = "SELECT id FROM login WHERE email = '$userEmail'";
    $userIdResult = mysqli_query($conn, $userIdQuery);

    if ($userIdResult && mysqli_num_rows($userIdResult) > 0) {
        $userData = mysqli_fetch_assoc($userIdResult);
        $userId = $userData['id'];

        // Retrieve the cart count for the user.
        $cartCountQuery = "SELECT COUNT(*) AS cart_count FROM cart WHERE user_id = $userId";
        $cartCountResult = mysqli_query($conn, $cartCountQuery);

        if ($cartCountResult) {
            $cartCount = mysqli_fetch_assoc($cartCountResult);
            $response = array("cartCount" => $cartCount['cart_count']);
        } else {
            $response = array("cartCount" => 0);
        }
    } else {
        $response = array("cartCount" => 0);
    }
} else {
    $response = array("cartCount" => 0);
}

echo json_encode($response);
?>
