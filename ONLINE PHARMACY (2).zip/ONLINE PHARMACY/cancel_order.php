<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Read the JSON data sent from the client
    $data = json_decode(file_get_contents("php://input"));

    // Validate and sanitize the order ID
    $orderId = filter_var($data->orderId, FILTER_VALIDATE_INT);

    if ($orderId === false) {
        http_response_code(400);
        echo "Invalid order ID.";
        exit;
    }

    // Perform an SQL query to update the order status
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "pharmacy";
    $port = "3307";
    
    $conn = mysqli_connect($host, $username, $password, $database, $port);

    if (!$conn) {
        http_response_code(500);
        echo "Database connection failed.";
        exit;
    }

    $updateQuery = "UPDATE orders SET order_status = 'Order Cancelled' WHERE id = $orderId";

    if (mysqli_query($conn, $updateQuery)) {

        // Redirect after a successful update
        header("Location: cancel.html");
        exit();
    } else {
        http_response_code(500); // Internal Server Error
        echo "Failed to update order status: " . mysqli_error($conn);
    }

    mysqli_close($conn);
} else {
    http_response_code(405); // Method Not Allowed
    echo "Invalid request method.";
}
?>
