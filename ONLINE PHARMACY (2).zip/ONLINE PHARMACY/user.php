<?php
session_start(); 

$host = "localhost";
$username = "root";
$password = "";
$database = "pharmacy";
$port = "3307";

$conn = mysqli_connect($host, $username, $password, $database, $port);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$users = array();

$sql = "SELECT name, email, contact FROM login";

$result = mysqli_query($conn, $sql);
if (!$result) {
    die("Error: " . mysqli_error($conn));
}

while ($row = mysqli_fetch_assoc($result)) {
    $users[] = $row;
}

mysqli_close($conn);

$user_data = json_encode($users);

header("Content-Type: application/json");

echo $user_data;
?>
