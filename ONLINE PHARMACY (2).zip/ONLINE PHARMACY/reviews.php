<?php

session_start();

$host = "localhost";
$username = "root";
$password = "";
$database = "pharmacy";
$port = "3307";

$conn = mysqli_connect($host, $username, $password, $database, $port);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_GET['product_id'])) {
    $productId = intval($_GET['product_id']);
    
    $sql = "SELECT name, rating, comment FROM product_reviews WHERE product_id = $productId";
    $result = mysqli_query($conn, $sql);

    if (!$result) {
        die("Error: " . mysqli_error($conn));
    }

    $reviews = array();

    while ($row = mysqli_fetch_assoc($result)) {
        $reviews[] = $row;
    }

    mysqli_close($conn);

    header("Content-Type: application/json");
    echo json_encode(array("reviews" => $reviews));
} else {
    echo "No product ID provided.";
}
?>
