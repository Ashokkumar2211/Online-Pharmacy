<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pharmacy";
$port = "3307";

$conn = new mysqli($servername, $username, $password, $dbname, $port);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['register'])) {
    $full_name = $_POST['full-name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $contact_number = $_POST['contact-number'];
    $door_no = $_POST['door-no'];
    $street = $_POST['street'];
    $pincode = $_POST['pincode'];
    $state = $_POST['state'];
    $city = $_POST['city'];
    $age = $_POST['age'];

    $address = $door_no . ', ' . $street . ', ' . $pincode . ', ' . $state . ', ' . $city;

    $query = "SELECT * FROM login WHERE email = '$email'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        echo "Email is already registered. Please log in or use a different email.";
    } else {
        $insert_query = "INSERT INTO login (name, email, password, contact, address, age) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insert_query);
        $stmt->bind_param("ssssss", $full_name, $email, $password, $contact_number, $address, $age);

        if ($stmt->execute()) {
            $_SESSION['user_id'] = $conn->insert_id;
            $_SESSION['user_email'] = $email;
            header("Location: popup.html");
            exit;
        } else {
            echo "Registration failed. Please try again.";
        }
        $stmt->close();
    }
}

if (isset($_POST['login'])) {
    $email = $_POST['login-email'];
    $password = $_POST['login-password'];

    $query = "SELECT * FROM login WHERE email = '$email'";
    $result = $conn->query($query);

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_email'] = $user['email'];
            header("Location: MODULE 2.html");
            exit;
        } else {
            echo "Incorrect password. Please try again.";
        }
    } else {
        echo "User not found. Please register or check your email.";
    }
}

if (isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: login.php");
}
?>
