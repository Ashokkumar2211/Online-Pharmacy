        <?php
        session_start();

        if (isset($_SESSION['user_email'])) {
            $userEmail = $_SESSION['user_email'];

            $host = "localhost";
            $username = "root";
            $password = "";
            $dbname = "pharmacy";
            $port = "3307";

            $conn = new mysqli($host, $username, $password, $dbname, $port);

            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // First, retrieve the user's ID based on their email.
            $userIdQuery = "SELECT id FROM login WHERE email = '$userEmail'";
            $userIdResult = mysqli_query($conn, $userIdQuery);

            if ($userIdResult && mysqli_num_rows($userIdResult) > 0) {
                $userData = mysqli_fetch_assoc($userIdResult);
                $userId = $userData['id'];

                // Fetch cart items for the logged-in user
                $fetchCartQuery = "SELECT products.name, cart.quantity, cart.price 
                    FROM cart
                    JOIN products ON cart.product_id = products.id
                    WHERE cart.user_id = $userId";

                $fetchCartResult = mysqli_query($conn, $fetchCartQuery);

                if ($fetchCartResult) {
                    $cartItems = array();

                    while ($row = mysqli_fetch_assoc($fetchCartResult)) {
                        $cartItems[] = $row;
                    }

                    // Check if any items were fetched
                    if (count($cartItems) > 0) {
                        // Return cart items as JSON
                        echo json_encode($cartItems);
                    } else {
                        // No items in the cart for this user
                        echo json_encode(array('message' => 'No items in the cart.'));
                    }
                } else {
                    // Handle the error, e.g., return an error message
                    echo json_encode(array('error' => 'Unable to fetch cart items.'));
                }
            } else {
                // Handle the case when the user is not found
                echo json_encode(array('error' => 'User not found.'));
            }

            // Close the database connection
            mysqli_close($conn);
        } else {
            // Handle the case when the user is not logged in
            echo json_encode(array('error' => 'User not authenticated.'));
        }
        ?>
