<?php
session_start();

if (isset($_GET['productId']) && isset($_SESSION['user_email'])) {
    $productId = $_GET['productId'];
    $userEmail = $_SESSION['user_email'];

    $host = "localhost";
    $username = "root";
    $password = "";
    $dbname = "pharmacy";
    $port = "3307";

    $conn = new mysqli($host, $username, $password, $dbname, $port);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // First, retrieve the user's ID based on their email.
    $userIdQuery = "SELECT id FROM login WHERE email = '$userEmail'";
    $userIdResult = mysqli_query($conn, $userIdQuery);

    if ($userIdResult && mysqli_num_rows($userIdResult) > 0) {
        $userData = mysqli_fetch_assoc($userIdResult);
        $userId = $userData['id'];

        // Check if the product is already in the user's cart.
        $checkCartQuery = "SELECT * FROM cart WHERE user_id = $userId AND product_id = $productId";
        $checkResult = mysqli_query($conn, $checkCartQuery);

        if (mysqli_num_rows($checkResult) == 0) {
            // Product not in the cart, insert it.
            $insertQuery = "INSERT INTO cart (user_id, product_id, quantity) VALUES ($userId, $productId, 1)";
            $insertResult = mysqli_query($conn, $insertQuery);

            if ($insertResult) {
                $response = array("success" => true);
            } else {
                $response = array("success" => false, "error" => "Failed to add product to cart.");
            }
        } else {
            $response = array("success" => false, "error" => "Product is already in the cart.");
        }
    } else {
        $response = array("success" => false, "error" => "User not found.");
    }
} else {
    $response = array("success" => false, "error" => "Invalid request.");
}

echo json_encode($response);
?>
