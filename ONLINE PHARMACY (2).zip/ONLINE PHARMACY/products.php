<?php
session_start();
$host = "localhost";
$username = "root";
$password = "";
$dbname = "pharmacy";
$port = "3307";

$conn = new mysqli($host, $username, $password, $dbname, $port);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sortBy = isset($_GET["sortBy"]) ? $_GET["sortBy"] : "default";
$category = isset($_GET["category"]) ? $_GET["category"] : "all";
$searchQuery = isset($_GET["search"]) ? $_GET["search"] : "";
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1; 
$productsPerPage = 9; 

$sql = "SELECT * FROM products WHERE 1";

if ($category != "all") {
    $sql .= " AND category = '$category'";
}

if (!empty($searchQuery)) {
    $searchQuery = mysqli_real_escape_string($conn, $searchQuery);
    $sql .= " AND (name LIKE '%$searchQuery%' OR description LIKE '%$searchQuery%')";
}

if ($sortBy == "name") {
    $sql .= " ORDER BY name ASC";
} elseif ($sortBy == "MRP") {
    $sql .= " ORDER BY MRP ASC";
}

$totalProductsQuery = mysqli_query($conn, $sql);
if (!$totalProductsQuery) {
    die("Error: " . mysqli_error($conn));
}
$totalProducts = mysqli_num_rows($totalProductsQuery);

$totalPages = ceil($totalProducts / $productsPerPage);

$offset = ($page - 1) * $productsPerPage;

$sql .= " LIMIT $offset, $productsPerPage";

$result = mysqli_query($conn, $sql);
if (!$result) {
    die("Error: " . mysqli_error($conn));
}

$products = array();

while ($row = mysqli_fetch_assoc($result)) {
    $products[] = $row;
}

mysqli_close($conn);

$product_data = json_encode(array("products" => $products, "totalPages" => $totalPages));

header("Content-Type: application/json");

echo $product_data;
?>
