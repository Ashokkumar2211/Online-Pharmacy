<?php
$servername = "localhost";
$username = "root";
$password = ""; 
$database = "pharmacy";
$port = "3307";

$conn = new mysqli($servername, $username, $password, $database, $port);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $productId = $_POST["productId"];
    $specialOffer = isset($_POST["specialOffer"]) ? 1 : 0;
    $fastSelling = isset($_POST["fastSelling"]) ? 1 : 0;

    $sql = "UPDATE products SET is_special_offer = ?, is_fast_selling = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iii", $specialOffer, $fastSelling, $productId);

    if ($stmt->execute()) {
        echo "Update successful!";
    } else {
        echo "Error updating offers: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "Invalid request method.";
}

$conn->close();
?>
