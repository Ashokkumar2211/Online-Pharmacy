<?php
$host = "localhost"; 
$username = "root";
$password = ""; 
$database = "cart";
$port = 3307; 

 {
    $conn = new mysqli("mysql:host=$host;port=$port;dbname=$database", $username, $password);
}  {
    die("Database connection failed: " . $e->getMessage());
}
?>
