<?php
include 'db_connection.php';

{
    $user_id = $_GET['user_id'];

    $stmt = new mysqli->prepare("SELECT * FROM cart WHERE user_id = ?");

    $stmt->execute([$user_id]);

    $cartItems = $stmt->fetchAll;

    echo json_encode($cartItems);
}  {
    echo "Error: " . $e->getMessage();
}
?>
