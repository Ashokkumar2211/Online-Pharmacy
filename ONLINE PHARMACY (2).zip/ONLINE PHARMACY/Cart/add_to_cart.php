<?php
include 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
     {
        $user_id = $_POST['user_id'];
        $product_name = $_POST['name'];
        $product_MRP = $_POST['MRP'];
        $quantity = $_POST['quantity'];

        $stmt = new mysqli("INSERT INTO cart (user_id, product_name, product_MRP, quantity) VALUES (?, ?, ?, ?)");

        $stmt->execute([$user_id, $product_name, $product_MRP, $quantity]);

        echo "Item added to cart successfully.";
    } 
    {
        echo "Error: " . $e->getMessage();
    }
}
?>
