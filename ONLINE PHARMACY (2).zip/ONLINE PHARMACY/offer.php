<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "pharmacy";
$port = "3307"; 

$conn = new mysqli($servername, $username, $password, $database, $port);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$specialOffers = [];
$fastSellingProducts = [];

$sqlSpecialOffers = "SELECT * FROM products WHERE is_special_offer = 1 LIMIT 3"; 
$resultSpecialOffers = $conn->query($sqlSpecialOffers);

if ($resultSpecialOffers->num_rows > 0) {
    while ($row = $resultSpecialOffers->fetch_assoc()) {
        $specialOffers[] = $row;
    }
}

$sqlFastSelling = "SELECT * FROM products WHERE is_fast_selling = 1 LIMIT 5"; 
$resultFastSelling = $conn->query($sqlFastSelling);

if ($resultFastSelling->num_rows > 0) {
    while ($row = $resultFastSelling->fetch_assoc()) {
        $fastSellingProducts[] = $row;
    }
}

$conn->close();

$data = [
    "specialOffers" => $specialOffers,
    "fastSellingProducts" => $fastSellingProducts,
];

header("Content-Type: application/json");
echo json_encode($data);
?>
