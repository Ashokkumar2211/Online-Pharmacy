<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "pharmacy";
$port = "3307";

$conn = new mysqli($servername, $username, $password, $database, $port);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];

    $targetDirectory = "uploads/";
    $targetFile = $targetDirectory . basename($_FILES["prescriptionFile"]["name"]);
    $uploadOk = 1;
    $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    if (file_exists($targetFile)) {
        echo "Sorry, this file already exists.";
        $uploadOk = 0;
    }

    if ($_FILES["prescriptionFile"]["size"] > 5000000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }

    if ($fileType !== "pdf" && $fileType !== "jpg" && $fileType !== "jpeg" && $fileType !== "png") {
        echo "Sorry, only PDF, JPG, JPEG, and PNG files are allowed.";
        $uploadOk = 0;
    }

    if ($uploadOk === 0) {
        echo "Sorry, your file was not uploaded.";
    } else {
        if (move_uploaded_file($_FILES["prescriptionFile"]["tmp_name"], $targetFile)) {
            $sql = "INSERT INTO prescriptions (name, email, prescription_path) VALUES (?, ?, ?)";
            
            // Use prepared statement
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sss", $name, $email, $targetFile);
            
            if ($stmt->execute()) {
                echo "Prescription submitted successfully.";
            } else {
                echo "Error: " . $stmt->error;
            }
            $stmt->close();
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
}

$conn->close();
?>
