<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Get the values from the POST data
    $product_id = $_POST["product_id"];
    $name = $_POST["name"];
    $rating = $_POST["rating"];
    $comment = $_POST["comment"];

    // You can add additional validation and sanitization here

    // Process the data, for example, by saving it to a database
    // Replace this part with your actual database connection and query

    // Example database connection
    $host = "localhost";
    $username = "root";
    $password = "";
    $dbname = "pharmacy";
    $port = "3307";
    
    $conn = new mysqli($host, $username, $password, $dbname, $port);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Example SQL query to insert the review into a database table
    $sql = "INSERT INTO product_reviews (product_id, name, rating, comment) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("isss", $product_id, $name, $rating, $comment);

        if ($stmt->execute()) {
            // Review successfully inserted into the database
            // You can send a success response or perform other actions here
            $response = array("success" => true);
            echo json_encode($response);
        } else {
            // Failed to insert the review
            // You can send an error response or perform other actions here
            $response = array("success" => false);
            echo json_encode($response);
        }

        $stmt->close();
    } else {
        // Error preparing the SQL statement
        $response = array("success" => false);
        echo json_encode($response);
    }

    $conn->close();
} else {
    // Handle invalid requests
    $response = array("success" => false, "error" => "Invalid request method.");
    echo json_encode($response);
}
?>
