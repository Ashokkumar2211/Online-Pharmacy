<?php
require 'vendor/autoload.php'; // Load the Twilio PHP library

$account_sid = 'AC4c2d27ca6bc216aed7c6333dfb6b8464'; // Replace with your Twilio Account SID
$auth_token = '4c6a30a852593a963b354e7a9b6f3b60'; // Replace with your Twilio Auth Token
$twilio_phone_number = '+17169515033'; // Replace with your Twilio phone number

session_start();

if (isset($_SESSION['user_email'])) {
    $userEmail = $_SESSION['user_email'];
} else {
    echo "Recipient email not found in the session.";
    exit;
}

$host = "localhost";
$username = "root";
$password = "";
$dbname = "pharmacy";
$port = "3307";

$conn = new mysqli($host, $username, $password, $dbname, $port);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Query the database to fetch the contact number and order details
$query = "SELECT orders.contact_number, login.name, orders.id FROM orders 
          JOIN login  ON orders.user_email = login.email
          WHERE orders.user_email = '$userEmail' ORDER BY orders.order_date DESC LIMIT 1";

$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $recipient = $row['contact_number'];
    $name = $row['name'];
    $orderID = $row['id'];

    // Message to send
    $message = "Hi $name, your Order ID $orderID has been placed in One Yes Online Pharmacy. Payment Successful. Please wait for further updates.";

    // Initialize the Twilio client
    $client = new Twilio\Rest\Client($account_sid, $auth_token);

    // Send an SMS
    $message = $client->messages->create(
        $recipient, // Recipient's phone number
        [
            'from' => $twilio_phone_number, // Your Twilio phone number
            'body' => $message,
        ]
    );

    // Process the Twilio response
    if ($message) {
        // SMS sent successfully
        header("Location: redirect.html");
        exit; 
    } else {
        // SMS sending failed
        echo "Error sending SMS.";
    }
} else {
    // Handle the case where the email was not found in the database
    echo "Recipient email not found in the database.";
}

// Close the database connection
$conn->close();
?>
