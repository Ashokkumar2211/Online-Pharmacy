<?php
session_start();

$host = "localhost";
$username = "root";
$password = "";
$database = "pharmacy";
$port = "3307";

$conn = mysqli_connect($host, $username, $password, $database, $port);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve the user's email from the session
if (isset($_SESSION['user_email'])) {
    $userEmail = $_SESSION['user_email'];

    // Modify the SQL query to include the user's email and payment_status
    $sql = "SELECT orders.id, orders.payment_method, orders.shipping_address, orders.contact_number, orders.total_amount, orders.order_date, orders.payment_status, orders.order_status, 
            GROUP_CONCAT(order_items.product_name) AS product_names,
            GROUP_CONCAT(order_items.product_mrp) AS product_mrps
            FROM orders
            LEFT JOIN order_items ON orders.id = order_items.order_id
            WHERE orders.user_email = '$userEmail'
            GROUP BY orders.id
            ORDER BY orders.order_date DESC";

    $result = $conn->query($sql);

    $orderHistory = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $orderHistory[] = [
                'id' => $row['id'],
                'payment_date' => $row['order_date'],
                'total_amount' => $row['total_amount'],
                'payment_method' => $row['payment_method'],
                'payment_status' => $row['payment_status'],
                'order_status' => $row['order_status'], // Include order_status
                'shipping_address' => $row['shipping_address'],
                'contact_number' => $row['contact_number'],
                'product_names' => explode(",", $row['product_names']),
                'product_mrps' => explode(",", $row['product_mrps'])
            ];
        }
    }

    $conn->close();

    header('Content-Type: application/json');
    echo json_encode($orderHistory);
} else {
   echo json_encode([]);
}
?>
