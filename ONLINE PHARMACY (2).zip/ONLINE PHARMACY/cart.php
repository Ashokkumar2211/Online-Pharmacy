<?php
// Start the PHP session to access user data
session_start();

// Database connection configuration
$host = "localhost";
$username = "root";
$password = "";
$database = "pharmacy";
$port = "3307";

// Create a database connection
$conn = mysqli_connect($host, $username, $password, $database, $port);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if a user is logged in
if (!isset($_SESSION['user_email'])) {
    header("Location: backend.php"); // Redirect to the login page if not logged in
    exit;
}

$userEmail = $_SESSION['user_email'];

$data = json_decode(file_get_contents("php://input"));

$paymentMethod = $data->method;
$shippingAddress = $data->address;
$contactNumber = $data->contactNumber;
$productNames = $data->names;
$productMRPs = $data->MRPs;
$total = $data->total;

$sql = "INSERT INTO orders (user_email, payment_method, shipping_address, contact_number, total_amount) 
        VALUES ('$userEmail', '$paymentMethod', '$shippingAddress', '$contactNumber', '$total')";

if ($conn->query($sql) === TRUE) {
    $orderId = $conn->insert_id;

    for ($i = 0; $i < count($productNames); $i++) {
        $productName = $productNames[$i];
        $productMRP = $productMRPs[$i];

        $sql = "INSERT INTO order_items (user_email, order_id, product_name, product_mrp) 
                VALUES ('$userEmail', '$orderId', '$productName', '$productMRP')";

        $conn->query($sql);
    }

    $response = array('success' => true, 'order_id' => $orderId);
    echo json_encode($response);
} else {
    $response = array('success' => false);
    echo json_encode($response);
}

$conn->close();
?>
