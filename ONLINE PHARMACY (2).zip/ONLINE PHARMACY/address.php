<?php
session_start();
$host = "localhost";
$username = "root";
$password = "";
$dbname = "pharmacy";
$port = "3307";

$conn = new mysqli($host, $username, $password, $dbname, $port);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_SESSION['user_email'])) {
    $userEmail = $_SESSION['user_email'];

    // Fetch the default address from the 'login' table
    $sql = "SELECT address FROM login WHERE email = '$userEmail'";

    $result = mysqli_query($conn, $sql);

    if ($result) {
        $user = mysqli_fetch_assoc($result);
        $defaultAddress = $user['address'];
    } else {
        // Handle the case when the query fails or the user does not exist.
        $defaultAddress = "Address not found";
    }
} else {
    // Handle the case when the user is not logged in or the session does not contain the email.
    $defaultAddress = "User not logged in";
}

mysqli_close($conn);

// Create an associative array to send the default address in JSON format
$response = array("defaultAddress" => $defaultAddress);

header('Content-Type: application/json');
echo json_encode($response);
?>
