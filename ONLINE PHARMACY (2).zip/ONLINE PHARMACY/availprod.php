<?php
session_start(); 

$host = "localhost";
$username = "root";
$password = "";
$database = "pharmacy";
$port = "3307";

$conn = mysqli_connect($host, $username, $password, $database, $port);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$products = array();

$sql = "SELECT name, MRP, description FROM products";

$result = mysqli_query($conn, $sql);
if (!$result) {
    die("Error: " . mysqli_error($conn));
}

while ($row = mysqli_fetch_assoc($result)) {
    $products[] = $row;
}

mysqli_close($conn);

$product_data = json_encode($products);

header("Content-Type: application/json");

echo $product_data;
?>
